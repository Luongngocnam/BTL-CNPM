# hash_pass.py
from flask_bcrypt import Bcrypt
from flask import Flask

# Khởi tạo Bcrypt
app = Flask(__name__)
bcrypt = Bcrypt(app)

# Mã hóa mật khẩu '123'
hashed_password = bcrypt.generate_password_hash('123').decode('utf-8')
print(f"Mật khẩu '123' (đã mã hóa): {hashed_password}")