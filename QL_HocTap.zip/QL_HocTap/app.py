# app.py
from flask import Flask, render_template, request, redirect, url_for, session, g, send_from_directory
from db_config import get_db_connection
from flask_bcrypt import Bcrypt 
import pyodbc
import os 
from werkzeug.utils import secure_filename 
from datetime import datetime 

# --- CẤU HÌNH UPLOAD FILE ---
UPLOAD_FOLDER = 'static/uploads'
SUBMISSIONS_FOLDER = os.path.join(UPLOAD_FOLDER, 'submissions') # Thư mục con cho bài nộp
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'rar'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
# THAY THẾ CHUỖI BÍ MẬT NÀY BẰNG MỘT CHUỖI KHÁC MẠNH VÀ NGẪU NHIÊN
app.secret_key = 'CHUOI_BI_MAT_MANH_CUA_BAN' 
bcrypt = Bcrypt(app) 

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# --- MIDDLEWARE: QUẢN LÝ KẾT NỐI DB ---
@app.before_request
def before_request():
    g.db = get_db_connection()

@app.teardown_request
def teardown_request(exception):
    db = getattr(g, 'db', None)
    if db is not None:
        db.close()

# --- ROUTES CHÍNH (INDEX, LOGIN, LOGOUT) ---

@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    user_type = session.get('user_type')
    if user_type == 'SV':
        return redirect(url_for('student_dashboard'))
    elif user_type == 'GV':
        return redirect(url_for('teacher_dashboard'))
        
    return "Lỗi phân quyền hệ thống."

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if g.db is None:
        return render_template('login.html', error="Lỗi kết nối CSDL.")

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor = g.db.cursor()
        
        try:
            cursor.execute("SELECT UserID, PasswordHash, UserType, FullName FROM Users WHERE Username = ?", username)
            user_data = cursor.fetchone()
            
            if user_data:
                user_id, hashed_password, user_type, full_name = user_data
                if bcrypt.check_password_hash(hashed_password, password):
                    
                    session['user_id'] = user_id
                    session['username'] = username
                    session['user_type'] = user_type
                    session['full_name'] = full_name
                    
                    if user_type == 'SV':
                        return redirect(url_for('student_dashboard'))
                    elif user_type == 'GV':
                        return redirect(url_for('teacher_dashboard'))
                else:
                    error = "Sai mật khẩu."
            else:
                error = "Tên đăng nhập không tồn tại."
                
        except pyodbc.Error as e:
            error = f"Lỗi truy vấn: {e}"

    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user_type', None)
    session.pop('username', None)
    session.pop('full_name', None)
    return redirect(url_for('login'))

# --- DASHBOARDS (ĐÃ CẬP NHẬT DÙNG RENDER_TEMPLATE) ---

@app.route('/student/dashboard')
def student_dashboard():
    if session.get('user_type') != 'SV':
        return redirect(url_for('login'))
        
    # SỬ DỤNG TEMPLATE EXTERNAL
    return render_template('student_dashboard.html', session=session)

@app.route('/teacher/dashboard')
def teacher_dashboard():
    if session.get('user_type') != 'GV':
        return redirect(url_for('login'))
        
    # SỬ DỤNG TEMPLATE EXTERNAL
    return render_template('teacher_dashboard.html', session=session)
    
# --- CHỨC NĂNG TẢI FILE (CHUNG) ---

@app.route('/download/<filename>')
def download_file(filename):
    """Cho phép người dùng đã đăng nhập tải file từ thư mục uploads."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    try:
        base_filename = secure_filename(filename)
        return send_from_directory(app.config['UPLOAD_FOLDER'], base_filename, as_attachment=True)
    except FileNotFoundError:
        return "File không tồn tại!", 404

# --- CHỨC NĂNG TẢI FILE BÀI NỘP ---

@app.route('/download/submission/<filename>')
def download_submission(filename):
    """Cho phép người dùng đã đăng nhập (chủ yếu là GV) tải file bài nộp."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    try:
        base_filename = secure_filename(filename)
        return send_from_directory(SUBMISSIONS_FOLDER, base_filename, as_attachment=True)
    except FileNotFoundError:
        return "File bài nộp không tồn tại!", 404


# --- CHỨC NĂNG XEM LỊCH HỌC (SINH VIÊN) ---

@app.route('/student/schedule', methods=['GET'])
def show_student_schedule():
    if session.get('user_type') != 'SV':
        return redirect(url_for('login'))
        
    if g.db is None:
        return render_template('student_schedule.html', error="Lỗi kết nối CSDL.", session=session, schedule=[])

    schedule_list = []
    error = None
    day_map = {2: 'Thứ Hai', 3: 'Thứ Ba', 4: 'Thứ Tư', 5: 'Thứ Năm', 6: 'Thứ Sáu', 7: 'Thứ Bảy'}

    try:
        cursor = g.db.cursor()
        sql_query = """
        SELECT c.CourseName, s.DayOfWeek, s.StartTime, s.EndTime, s.Location
        FROM Schedule s
        JOIN Courses c ON s.CourseID = c.CourseID
        ORDER BY s.DayOfWeek, s.StartTime
        """
        cursor.execute(sql_query)
        
        results = cursor.fetchall()
        
        for row in results:
            schedule_list.append({
                'course_name': row[0],
                'day_of_week': day_map.get(row[1], 'Không xác định'), 
                'start_time': str(row[2])[:5], 
                'end_time': str(row[3])[:5],
                'location': row[4]
            })

    except pyodbc.Error as e:
        error = f"Lỗi truy vấn lịch học: {e}"
        print(error)
        
    return render_template('student_schedule.html', 
                           schedule=schedule_list, 
                           error=error, 
                           session=session)

# --- CHỨC NĂNG ĐĂNG LỊCH HỌC (GIÁO VIÊN) ---

@app.route('/teacher/schedule', methods=['GET'])
def show_add_schedule_form():
    if session.get('user_type') != 'GV':
        return redirect(url_for('login'))
        
    return render_template('teacher_schedule_add.html', session=session)


@app.route('/teacher/schedule/add', methods=['POST'])
def add_schedule():
    if session.get('user_type') != 'GV':
        return redirect(url_for('login'))
        
    if g.db is None:
        return render_template('teacher_schedule_add.html', error="Lỗi kết nối CSDL.", session=session)

    try:
        course_name = request.form['course_name']
        day_of_week = request.form['day_of_week']
        start_time = request.form['start_time']
        end_time = request.form['end_time']
        location = request.form['location']
        teacher_id = session.get('user_id')
        
        cursor = g.db.cursor()
        
        # 1. Kiểm tra và Thêm Môn học (Courses)
        cursor.execute("SELECT CourseID FROM Courses WHERE CourseName = ? AND TeacherID = ?", course_name, teacher_id)
        course_data = cursor.fetchone()
        
        if course_data:
            course_id = course_data[0]
        else:
            cursor.execute("INSERT INTO Courses (CourseName, TeacherID) VALUES (?, ?)", course_name, teacher_id)
            g.db.commit()
            cursor.execute("SELECT @@IDENTITY AS CourseID")
            course_id = cursor.fetchone()[0]
        
        # 2. Thêm Lịch học (Schedule)
        sql_insert_schedule = """
        INSERT INTO Schedule (CourseID, DayOfWeek, StartTime, EndTime, Location)
        VALUES (?, ?, ?, ?, ?)
        """
        cursor.execute(sql_insert_schedule, course_id, day_of_week, start_time, end_time, location)
        g.db.commit()
        
        return render_template('teacher_schedule_add.html', 
                                 message=f"Đã thêm lịch học thành công cho môn {course_name}!",
                                 session=session)

    except pyodbc.Error as e:
        g.db.rollback() 
        error_msg = f"Lỗi SQL: {e}"
        print(error_msg)
        return render_template('teacher_schedule_add.html', error=error_msg, session=session)


# --- CHỨC NĂNG ĐĂNG TẢI BÀI TẬP VÀ TÀI LIỆU (GIÁO VIÊN) ---

@app.route('/teacher/assignment', methods=['GET'])
def show_assignment_upload_form():
    if session.get('user_type') != 'GV':
        return redirect(url_for('login'))
        
    courses = []
    if g.db:
        cursor = g.db.cursor()
        try:
            cursor.execute("SELECT CourseID, CourseName FROM Courses WHERE TeacherID = ?", session.get('user_id'))
            for row in cursor.fetchall():
                courses.append({'CourseID': row[0], 'CourseName': row[1]})
        except pyodbc.Error as e:
            print(f"Lỗi truy vấn môn học: {e}")
            
    return render_template('teacher_assignment_upload.html', session=session, courses=courses)


@app.route('/teacher/assignment/upload', methods=['POST'])
def upload_assignment():
    if session.get('user_type') != 'GV':
        return redirect(url_for('login'))
    
    courses = []
    if g.db:
        cursor = g.db.cursor()
        try:
            cursor.execute("SELECT CourseID, CourseName FROM Courses WHERE TeacherID = ?", session.get('user_id'))
            for row in cursor.fetchall():
                courses.append({'CourseID': row[0], 'CourseName': row[1]})
        except pyodbc.Error as e:
            print(f"Lỗi truy vấn môn học: {e}")
    
    if g.db is None:
        return render_template('teacher_assignment_upload.html', error="Lỗi kết nối CSDL.", session=session, courses=courses)


    try:
        # 1. Xử lý File Upload
        if 'file' not in request.files:
            return render_template('teacher_assignment_upload.html', error="Không tìm thấy file.", session=session, courses=courses)
            
        file = request.files['file']
        
        if file.filename == '':
            return render_template('teacher_assignment_upload.html', error="Thiếu tên file.", session=session, courses=courses)
        
        if not allowed_file(file.filename):
              return render_template('teacher_assignment_upload.html', error="Định dạng file không hợp lệ.", session=session, courses=courses)


        filename = secure_filename(file.filename)
        if not os.path.exists(app.config['UPLOAD_FOLDER']):
            os.makedirs(app.config['UPLOAD_FOLDER'])
            
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Lưu TÊN FILE an toàn vào DB
        db_filepath = filename 
        
        file.save(filepath)
        
        # 2. Xử lý Dữ liệu Form và DB
        course_id = request.form['course_id']
        title = request.form['title']
        description = request.form.get('description', '') 
        
        # Xử lý Deadline
        deadline_str = request.form.get('deadline', None)
        deadline = None
        if deadline_str:
            try:
                dt_object = datetime.strptime(deadline_str, '%Y-%m-%dT%H:%M')
                deadline = dt_object.strftime('%Y-%m-%d %H:%M:%S')
            except ValueError:
                return render_template('teacher_assignment_upload.html', error="Lỗi định dạng ngày/giờ.", session=session, courses=courses)

        cursor = g.db.cursor()
        
        # Chèn dữ liệu vào bảng Assignments 
        sql_insert = """
        INSERT INTO Assignments (CourseID, Title, Description, FilePath, Deadline)
        VALUES (?, ?, ?, ?, ?)
        """
        cursor.execute(sql_insert, course_id, title, description, db_filepath, deadline)
        g.db.commit()
        
        return render_template('teacher_assignment_upload.html', 
                                 message=f"Đã thêm bài tập '{title}' thành công!",
                                 session=session,
                                 courses=courses)
        
    except pyodbc.Error as e:
        g.db.rollback()
        error_msg = f"Lỗi SQL khi chèn bài tập: {e}"
        print(error_msg)
        return render_template('teacher_assignment_upload.html', error=error_msg, session=session, courses=courses)


# --- CHỨC NĂNG XEM VÀ TẢI BÀI TẬP (SINH VIÊN) ---

@app.route('/student/assignments')
def show_student_assignments():
    if session.get('user_type') != 'SV':
        return redirect(url_for('login'))
        
    if g.db is None:
        return render_template('student_assignments.html', error="Lỗi kết nối CSDL.", assignments=[])

    assignments_list = []
    error = None
    student_id = session.get('user_id')

    try:
        cursor = g.db.cursor()
        sql_query = """
        SELECT a.AssignmentID, c.CourseName, a.Title, a.Description, a.FilePath, a.Deadline, a.UploadDate, s.Grade
        FROM Assignments a
        JOIN Courses c ON a.CourseID = c.CourseID
        LEFT JOIN Submissions s ON a.AssignmentID = s.AssignmentID AND s.StudentID = ?
        ORDER BY a.Deadline DESC
        """
        cursor.execute(sql_query, student_id)
        
        results = cursor.fetchall()
        
        for row in results:
            filename_to_download = row[4] 
            
            assignments_list.append({
                'id': row[0],
                'course_name': row[1],
                'title': row[2],
                'description': row[3],
                'file_path': filename_to_download, 
                'deadline': row[5].strftime('%Y-%m-%d %H:%M') if row[5] else 'N/A',
                'upload_date': row[6].strftime('%Y-%m-%d %H:%M') if row[6] else 'N/A', 
                'grade': row[7] if row[7] is not None else 'N/A' 
            })

    except pyodbc.Error as e:
        error = f"Lỗi truy vấn bài tập: {e}"
        print(error)
        
    return render_template('student_assignments.html', 
                           assignments=assignments_list, 
                           error=error, 
                           session=session)

# --- CHỨC NĂNG NỘP BÀI TẬP (SINH VIÊN) ---

@app.route('/student/assignment/submit/<int:assignment_id>', methods=['GET'])
def show_submit_form(assignment_id):
    """Hiển thị form nộp bài cho AssignmentID cụ thể."""
    if session.get('user_type') != 'SV' or g.db is None:
        return redirect(url_for('login'))
        
    assignment = None
    try:
        cursor = g.db.cursor()
        sql_query = """
        SELECT a.AssignmentID, c.CourseName, a.Title, a.Deadline
        FROM Assignments a JOIN Courses c ON a.CourseID = c.CourseID
        WHERE a.AssignmentID = ?
        """
        cursor.execute(sql_query, assignment_id)
        row = cursor.fetchone()
        
        if row:
            assignment = {
                'id': row[0],
                'course_name': row[1],
                'title': row[2],
                'deadline': row[3].strftime('%Y-%m-%d %H:%M') if row[3] else 'N/A'
            }
        
    except pyodbc.Error as e:
        print(f"Lỗi truy vấn assignment: {e}")

    if not assignment:
        return redirect(url_for('show_student_assignments'))
        
    return render_template('student_submit_assignment.html', assignment=assignment, session=session)


@app.route('/student/assignment/submit/<int:assignment_id>', methods=['POST'])
def submit_assignment(assignment_id):
    """Xử lý việc upload bài nộp và lưu thông tin vào bảng Submissions."""
    if session.get('user_type') != 'SV' or g.db is None:
        return redirect(url_for('login'))
        
    student_id = session.get('user_id')
    
    assignment_info = {} 
    try:
        cursor = g.db.cursor()
        cursor.execute("SELECT Title, Deadline FROM Assignments WHERE AssignmentID = ?", assignment_id)
        row = cursor.fetchone()
        if row:
            assignment_info = {'id': assignment_id, 'title': row[0]}
    except:
        pass 

    
    # 1. Xử lý File Upload
    if 'file' not in request.files:
        return render_template('student_submit_assignment.html', error="Không tìm thấy file.", assignment=assignment_info, session=session)
        
    file = request.files['file']
    if file.filename == '' or not allowed_file(file.filename):
        return render_template('student_submit_assignment.html', error="File không hợp lệ hoặc thiếu tên.", assignment=assignment_info, session=session)

    # Tạo tên file: [AssignmentID]_[StudentID]_[TênFileGốcAnToàn]
    filename_safe = secure_filename(file.filename)
    unique_filename = f"{assignment_id}_{student_id}_{filename_safe}"
    
    # Đảm bảo thư mục submissions tồn tại
    if not os.path.exists(SUBMISSIONS_FOLDER):
        os.makedirs(SUBMISSIONS_FOLDER)
        
    filepath = os.path.join(SUBMISSIONS_FOLDER, unique_filename)
    
    # Lưu TÊN FILE an toàn vào DB
    db_filepath = unique_filename 
    
    # Lưu file
    file.save(filepath)
    
    # 2. Xử lý Dữ liệu Form và DB
    try:
        cursor = g.db.cursor()
        
        # Kiểm tra xem sinh viên đã nộp bài này chưa 
        cursor.execute("SELECT SubmissionID FROM Submissions WHERE AssignmentID = ? AND StudentID = ?", assignment_id, student_id)
        existing_submission = cursor.fetchone()
        
        if existing_submission:
            # Nếu đã nộp: Cập nhật bài nộp mới (reset điểm)
            sql_query = """
            UPDATE Submissions SET FilePath = ?, SubmitDate = GETDATE(), Grade = NULL
            WHERE SubmissionID = ?
            """ 
            cursor.execute(sql_query, db_filepath, existing_submission[0])
            message = "Cập nhật bài nộp thành công! (Điểm cũ đã bị xóa, bài nộp này cần được chấm lại)"
        else:
            # Nếu chưa nộp: Chèn mới
            sql_query = """
            INSERT INTO Submissions (AssignmentID, StudentID, FilePath)
            VALUES (?, ?, ?)
            """
            cursor.execute(sql_query, assignment_id, student_id, db_filepath)
            message = "Nộp bài thành công!"
            
        g.db.commit()
        
        return render_template('student_submit_assignment.html', message=message, assignment=assignment_info, session=session)
        
    except pyodbc.Error as e:
        g.db.rollback()
        error_msg = f"Lỗi SQL khi nộp bài: {e}"
        print(error_msg)
        return render_template('student_submit_assignment.html', error=error_msg, assignment=assignment_info, session=session)


# --- CHỨC NĂNG CHẤM ĐIỂM (GIÁO VIÊN) ---

@app.route('/teacher/submissions')
def show_teacher_submissions():
    """Hiển thị danh sách các bài tập của GV và bài nộp tương ứng."""
    if session.get('user_type') != 'GV':
        return redirect(url_for('login'))
        
    if g.db is None:
        return render_template('teacher_submissions.html', error="Lỗi kết nối CSDL.", assignments=[])

    teacher_id = session.get('user_id')
    assignments_data = []
    error = None

    try:
        cursor = g.db.cursor()
        
        sql_assignments = """
        SELECT a.AssignmentID, a.Title, a.Deadline, c.CourseName
        FROM Assignments a
        JOIN Courses c ON a.CourseID = c.CourseID
        WHERE c.TeacherID = ?
        ORDER BY a.UploadDate DESC
        """
        cursor.execute(sql_assignments, teacher_id)
        assignments = cursor.fetchall()

        for assign_id, title, deadline, course_name in assignments:
            sql_submissions = """
            SELECT s.SubmissionID, u.FullName, u.UserID, s.FilePath, s.SubmitDate, s.Grade
            FROM Submissions s
            JOIN Users u ON s.StudentID = u.UserID
            WHERE s.AssignmentID = ?
            ORDER BY s.SubmitDate DESC
            """
            cursor.execute(sql_submissions, assign_id)
            submissions = []
            for sub_id, student_name, student_id, file_path, submit_date, grade in cursor.fetchall():
                filename = file_path or 'N/A' 
                
                submissions.append({
                    'id': sub_id,
                    'student_name': student_name,
                    'student_id': student_id,
                    'file_path': filename,
                    'submit_date': submit_date.strftime('%Y-%m-%d %H:%M') if submit_date else 'N/A',
                    'grade': grade if grade is not None else 'Chưa chấm',
                })

            assignments_data.append({
                'id': assign_id,
                'title': title,
                'course_name': course_name,
                'deadline': deadline.strftime('%Y-%m-%d %H:%M') if deadline else 'N/A',
                'submissions': submissions
            })

    except pyodbc.Error as e:
        error = f"Lỗi truy vấn danh sách bài nộp: {e}"
        print(error)
        
    return render_template('teacher_submissions.html', 
                            assignments=assignments_data, 
                            error=error, 
                            session=session)

@app.route('/teacher/grade/<int:submission_id>', methods=['GET'])
def show_grading_form(submission_id):
    """Hiển thị form để giáo viên nhập điểm."""
    if session.get('user_type') != 'GV':
        return redirect(url_for('login'))

    submission = None
    error = None
    
    try:
        cursor = g.db.cursor()
        sql_query = """
        SELECT s.SubmissionID, a.AssignmentID, a.Title, c.CourseName, u.FullName, s.Grade, s.FilePath
        FROM Submissions s
        JOIN Assignments a ON s.AssignmentID = a.AssignmentID
        JOIN Courses c ON a.CourseID = c.CourseID
        JOIN Users u ON s.StudentID = u.UserID
        WHERE s.SubmissionID = ? AND c.TeacherID = ?
        """
        cursor.execute(sql_query, submission_id, session.get('user_id'))
        row = cursor.fetchone()

        if row:
            submission = {
                'id': row[0],
                'assignment_id': row[1],
                'assignment_title': row[2],
                'course_name': row[3],
                'student_name': row[4],
                'current_grade': row[5] if row[5] is not None else 'Chưa chấm',
                'file_path': row[6] or 'N/A'
            }
        else:
             error = "Bài nộp không tồn tại hoặc bạn không có quyền chấm."

    except pyodbc.Error as e:
        error = f"Lỗi truy vấn thông tin chấm điểm: {e}"
        print(error)
        
    if not submission:
        return render_template('grading_form.html', error=error or "Không tìm thấy bài nộp.", session=session)
        
    return render_template('grading_form.html', submission=submission, session=session, error=error)


@app.route('/teacher/grade/<int:submission_id>', methods=['POST'])
def submit_grade(submission_id):
    """Xử lý việc lưu điểm vào CSDL."""
    if session.get('user_type') != 'GV':
        return redirect(url_for('login'))

    message = None
    error = None
    
    submission_info = {'id': submission_id} 
    
    try:
        grade_value = request.form['grade']
        
        try:
            grade = float(grade_value)
            if not (0 <= grade <= 10):
                raise ValueError("Điểm phải từ 0 đến 10.")
        except ValueError as ve:
            # Lấy lại thông tin đầy đủ để hiển thị lại form
            cursor = g.db.cursor()
            cursor.execute("""
                SELECT a.Title, c.CourseName, u.FullName, s.Grade, s.FilePath
                FROM Submissions s JOIN Assignments a ON s.AssignmentID = a.AssignmentID
                JOIN Courses c ON a.CourseID = c.CourseID
                JOIN Users u ON s.StudentID = u.UserID
                WHERE s.SubmissionID = ?
            """, submission_id)
            row = cursor.fetchone()
            if row:
                submission_info = {
                    'id': submission_id, 'assignment_title': row[0], 
                    'course_name': row[1], 'student_name': row[2], 
                    'current_grade': row[3], 'file_path': row[4]
                }
            return render_template('grading_form.html', error=f"Điểm không hợp lệ: {ve}", submission=submission_info, session=session)

        cursor = g.db.cursor()
        
        sql_update = """
        UPDATE Submissions 
        SET Grade = ?
        WHERE SubmissionID = ? AND AssignmentID IN 
        (SELECT AssignmentID FROM Assignments WHERE CourseID IN 
        (SELECT CourseID FROM Courses WHERE TeacherID = ?))
        """
        cursor.execute(sql_update, grade, submission_id, session.get('user_id'))
        
        if cursor.rowcount == 0:
            g.db.rollback()
            error = "Không tìm thấy bài nộp hoặc bạn không có quyền chấm bài này."
        else:
            g.db.commit()
            message = f"Đã cập nhật điểm **{grade}** thành công!"
        
    except pyodbc.Error as e:
        g.db.rollback()
        error = f"Lỗi SQL khi lưu điểm: {e}"
        print(error)
    
    # Lấy lại thông tin bài nộp để hiển thị 
    try:
        cursor = g.db.cursor()
        sql_query = """
        SELECT a.AssignmentID, a.Title, c.CourseName, u.FullName, s.Grade, s.FilePath
        FROM Submissions s JOIN Assignments a ON s.AssignmentID = a.AssignmentID
        JOIN Courses c ON a.CourseID = c.CourseID
        JOIN Users u ON s.StudentID = u.UserID
        WHERE s.SubmissionID = ?
        """
        cursor.execute(sql_query, submission_id)
        row = cursor.fetchone()
        
        if row:
            submission_info = {
                'id': submission_id,
                'assignment_id': row[0],
                'assignment_title': row[1],
                'course_name': row[2],
                'student_name': row[3],
                'current_grade': row[4] if row[4] is not None else 'Chưa chấm',
                'file_path': row[5] or 'N/A'
            }
        else:
            error = error or "Không tìm thấy bài nộp sau khi cố gắng cập nhật."

    except pyodbc.Error as e:
        error = error or f"Lỗi truy vấn thông tin: {e}"
        
    return render_template('grading_form.html', 
                            message=message, 
                            error=error, 
                            submission=submission_info, 
                            session=session)

# --- CHỨC NĂNG THÔNG BÁO ---

@app.route('/notifications')
def notifications():
    """Hiển thị thông báo và điểm số (SV)."""
    if 'user_id' not in session:
        return redirect(url_for('login'))

    alerts = []
    error = None
    
    if g.db and session.get('user_type') == 'SV':
        student_id = session.get('user_id')
        try:
            cursor = g.db.cursor()
            sql_query = """
            SELECT c.CourseName, a.Title, s.Grade, GETDATE() AS GradeDate
            FROM Submissions s
            JOIN Assignments a ON s.AssignmentID = a.AssignmentID
            JOIN Courses c ON a.CourseID = c.CourseID
            WHERE s.StudentID = ? AND s.Grade IS NOT NULL
            ORDER BY GradeDate DESC
            """
            cursor.execute(sql_query, student_id)
            for row in cursor.fetchall():
                grade_date = row[3] 
                alerts.append({
                    'type': 'grade',
                    'message': f"**ĐIỂM MỚI:** Môn **{row[0]}** - Bài tập '{row[1]}'. Điểm của bạn: **{row[2]}**/10.",
                    'date': grade_date 
                })

        except pyodbc.Error as e:
            error = f"Lỗi truy vấn điểm số: {e}"
            print(error)
            
    elif g.db and session.get('user_type') == 'GV':
        teacher_id = session.get('user_id')
        try:
             cursor = g.db.cursor()
             sql_query = """
             SELECT COUNT(s.SubmissionID)
             FROM Submissions s
             JOIN Assignments a ON s.AssignmentID = a.AssignmentID
             JOIN Courses c ON a.CourseID = c.CourseID
             WHERE c.TeacherID = ? AND s.Grade IS NULL
             """
             cursor.execute(sql_query, teacher_id)
             count = cursor.fetchone()[0]
             
             if count > 0:
                 alerts.append({
                     'type': 'task',
                     'message': f"Bạn có **{count}** bài nộp đang chờ được chấm. <a href='{url_for('show_teacher_submissions')}'>Đến trang chấm điểm</a>",
                     'date': datetime.now()
                 })

        except pyodbc.Error as e:
            error = f"Lỗi truy vấn thông báo GV: {e}"
            print(error)
            
    
    # Thêm thông báo chung
    alerts.append({
        'type': 'info',
        'message': "Chào mừng đến với hệ thống quản lý học tập. Vui lòng kiểm tra lịch học thường xuyên.",
        'date': datetime.now()
    })
            
    return render_template('notifications.html', alerts=alerts, session=session, error=error)


if __name__ == '__main__':
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    if not os.path.exists(SUBMISSIONS_FOLDER):
        os.makedirs(SUBMISSIONS_FOLDER)
        
    app.run(debug=True)