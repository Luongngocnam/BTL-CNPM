import pyodbc

# Thay đổi các thông số kết nối sau cho phù hợp với môi trường của bạn
# Ví dụ: Server: NAM\SQL2022, Database: QL_HocTap_DB
SERVER = 'NAM\SQL2022' 
DATABASE = 'QL_HocTap_DB'
DRIVER = '{ODBC Driver 17 for SQL Server}' 

def get_db_connection():
    try:
        # Sử dụng Windows Authentication
        conn_str = f'DRIVER={DRIVER};SERVER={SERVER};DATABASE={DATABASE};Trusted_Connection=yes;'
        conn = pyodbc.connect(conn_str)
        return conn
    except pyodbc.Error as ex:
        print(f"Lỗi kết nối CSDL: {ex}")
        return None